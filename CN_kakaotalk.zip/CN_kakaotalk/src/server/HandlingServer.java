package server;

public class HandlingServer {

  public static void main(String[] args) {
    
    ServerHandler serverHandler = new ServerHandler();
    serverHandler.startServer();

  }
 
}